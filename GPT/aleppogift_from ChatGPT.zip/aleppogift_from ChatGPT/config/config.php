<?php
// Database Configuration
/*
$host = "mmurhaf50350.ipagemysql.com";
$user = "ephonetw_mmurhaf";
$password = "Salem1972#i";
$database = 'ephonetw_ephone';

define('DB_HOST', 'localhost');
define('DB_NAME', 'aleppogift');
define('DB_USER', 'root');
define('DB_PASS', '');
*/
define('DB_HOST', 'mmurhaf50350.ipagemysql.com');
define('DB_NAME', 'aleppogift');
define('DB_USER', 'mmurhaf');
define('DB_PASS', 'Salem1972#i');



// Site Configuration
define('SITE_URL', 'http://localhost:83/aleppogift/');

// Email Configuration
define('EMAIL_FROM', 'sales@aleppogift.com');
define('EMAIL_FROM_NAME', 'AleppoGift');
define('SMTP_HOST', 'smtp.ipage.com');
define('SMTP_USERNAME', 'sales@aleppogift.com');
define('SMTP_PASSWORD', 'Salem1972#i');
define('SMTP_PORT', value: 465);

// Ziina Payment API
define('ZIINA_API_URL', 'https://api-v2.ziina.com/api/payment_intent');
define('ZIINA_API_KEY', 'Cyhd+lvjI8qiXN50qklhMjtp4g7qQTEHE7w1vvJ5nU1MbO7nAmGzA30SvOi05/VI');
?>
