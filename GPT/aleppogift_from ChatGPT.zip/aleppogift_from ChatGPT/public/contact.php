<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us - AleppoGift</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<h2>Contact Us</h2>

<p>Email: support@aleppogift.com</p>
<p>Phone: +971-XX-XXX-XXXX</p>
<p>Address: Your Full Address Here</p>

<p><a href="index.php">Back to Home</a></p>

</body>
</html>
